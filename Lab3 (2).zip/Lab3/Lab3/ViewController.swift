//
//  ViewController.swift
//  Lab3
//
//  Created by Bunny on 13/06/21.
//  Copyright © 2021 Bunny. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

